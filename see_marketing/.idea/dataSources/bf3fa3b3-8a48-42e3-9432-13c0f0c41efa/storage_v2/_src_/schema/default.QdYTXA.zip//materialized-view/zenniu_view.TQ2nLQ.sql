CREATE
MATERIALIZED
VIEW
default
.
zenniu_view
TO
default
.
zenniu_detail
(
    `account` String,
    `appId` String,
    `appVersion` String,
    `carrier` String,
    `deviceId` String,
    `deviceType` String,
    `eventId` String,
    `ip` String,
    `latitude` Float64,
    `longitude` Float64,
    `netType` String,
    `osName` String,
    `osVersion` String,
    `properties` Map(String, String),
    `releaseChannel` String,
    `resolution` String,
    `sessionId` String,
    `timeStamp` Int64
)
AS
SELECT account,
       appId,
       appVersion,
       carrier,
       deviceId,
       deviceType,
       eventId,
       ip,
       latitude,
       longitude,
       netType,
       osName,
       osVersion,
       properties,
       releaseChannel,
       resolution,
       sessionId,
       timeStamp
FROM default.zenniu_detail_kafka;

